import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = "/workspace/scratch/54533be54f46";
const inputDir = path.join(root, "analysis/intermediate");
const outputDir = path.join(root, "outputs/jawra_minor_revision");
await fs.mkdir(outputDir, { recursive: true });

const specs = [
  ["Summary", "Overall_metrics.json"],
  ["Per origin", "Per_origin_metrics.json"],
  ["Origin month", "Origin_month_metrics.json"],
  ["Lead descriptive", "Lead_metrics_descriptive.json"],
  ["Leave one out", "Leave_one_origin_out.json"],
  ["LOO summary", "LOO_summary.json"],
  ["Precip events", "Precip_contingency.json"],
  ["Tuning sensitivity", "Tuning_sensitivity.json"],
  ["Predictions", "Predictions.json"],
  ["Methods", "Methods.json"],
];

const wb = Workbook.create();
const font = "Arial";
for (const [sheetName, fileName] of specs) {
  const raw = JSON.parse(await fs.readFile(path.join(inputDir, fileName), "utf8"));
  const rows = raw.map(row => row.map(v => v && typeof v === "object" && v.__date__ ? new Date(v.__date__) : v));
  const sh = wb.worksheets.add(sheetName);
  sh.showGridLines = false;
  sh.getRange("A1").write(rows);
  const used = sh.getUsedRange();
  used.format.font = { name: font, size: 10, color: "#1F2937" };
  used.format.verticalAlignment = "center";
  const header = sh.getRangeByIndexes(0, 0, 1, rows[0].length);
  header.format = {
    fill: "#1F4E78",
    font: { name: font, size: 10, bold: true, color: "#FFFFFF" },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
    borders: { preset: "inside", style: "thin", color: "#FFFFFF" },
  };
  header.format.rowHeight = 30;
  used.format.autofitColumns();
  used.format.autofitRows();
  if (rows[0].some(v => String(v).toLowerCase() === "variable")) sh.getRange("A:A").format.columnWidth = 24;
  if (rows[0].some(v => String(v).toLowerCase() === "model")) sh.getRange("B:B").format.columnWidth = 18;
  if (sheetName === "LOO summary") sh.getRange("C:F").format.columnWidth = 16;
  if (sheetName === "Precip events") sh.getRange("A:J").format.columnWidth = 16;
  if (sheetName === "Methods") {
    sh.getRange("A:A").format.columnWidth = 22;
    sh.getRange("B:B").format.columnWidth = 62;
  }
  for (let c = 0; c < rows[0].length; c++) {
    const name = String(rows[0][c]).toLowerCase();
    const col = sh.getRangeByIndexes(1, c, Math.max(rows.length - 1, 1), 1);
    if (name.includes("date") || name === "origin" || name.includes("omitted_origin")) col.setNumberFormat("yyyy-mm-dd");
    else if (/(rmse|mae|bias|rank|pod|far|csi|actual|prediction|error)/.test(name)) col.setNumberFormat("0.000");
    else if (/(^n$|hits|misses|alarms|negatives|lead|month|wins)/.test(name)) col.setNumberFormat("0");
  }
  sh.freezePanes.freezeRows(1);
  if (rows[0].length > 2) sh.freezePanes.freezeColumns(Math.min(2, rows[0].length));
  const tableName = "T" + sheetName.replace(/[^A-Za-z0-9]/g, "");
  sh.tables.add(used, true, tableName).style = "TableStyleMedium2";
}

const summary = wb.worksheets.getItem("Summary");
summary.tabColor = "#1F4E78";
const methods = wb.worksheets.getItem("Methods");
methods.tabColor = "#7F8C8D";
wb.recalculate();

const check = await wb.inspect({ kind: "table", sheetId: "Summary", range: "A1:G34", include: "values,formulas", tableMaxRows: 34, tableMaxCols: 8, maxChars: 8000 });
console.log(check.ndjson);
const errors = await wb.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!", options: { useRegex: true, maxResults: 100 }, summary: "formula errors" });
console.log(errors.ndjson);
for (const name of ["Summary", "LOO summary", "Precip events", "Methods"]) {
  const preview = await wb.render({ sheetName: name, autoCrop: "all", scale: 1, format: "png" });
  await fs.writeFile(path.join(outputDir, `${name.replace(/ /g, "_")}.png`), new Uint8Array(await preview.arrayBuffer()));
}
const out = await SpreadsheetFile.exportXlsx(wb);
await out.save(path.join(outputDir, "JAWRA_Minor_Revision_Robustness.xlsx"));
