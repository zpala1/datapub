#!/usr/bin/env python3
"""Reproducible robustness analysis for JAWRA manuscript 7173851.

The script reads the source-verified monthly workbook, constructs a complete
monthly index, and performs calendar-balanced rolling-origin forecasts.  Every
forecast is issued without updating from observations inside its 12-month
horizon.  Learning models therefore generate recursive forecasts, appending
their own prediction to the next input window.
"""

from __future__ import annotations

import json
import os
import random
import time
import warnings
from dataclasses import dataclass
from pathlib import Path

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import RobustScaler
from statsmodels.tsa.statespace.sarimax import SARIMAX
from tbats import TBATS
from xgboost import XGBRegressor

warnings.filterwarnings("ignore")

SEED = 20261106
HORIZON = 12
INPUT_WINDOWS = (12, 24, 36)
ROBUSTNESS_ORIGINS = pd.date_range("2020-07-01", "2022-06-01", freq="MS")
VARIABLES = {
    "sunshine_hours_total": "Sunshine total (h)",
    "temperature_c_mean": "Temperature mean (°C)",
    "precipitation_mm_total": "Precipitation total (mm)",
    "humidity_pct_mean": "Humidity mean (%)",
}
AUTO_ORDERS = {
    "sunshine_hours_total": ((0, 0, 2), (0, 1, 1, 12)),
    "temperature_c_mean": ((2, 0, 1), (1, 1, 0, 12)),
    "precipitation_mm_total": ((0, 0, 0), (1, 1, 0, 12)),
    "humidity_pct_mean": ((0, 0, 2), (0, 1, 1, 12)),
}
LEARNING_PARAMS = {
    "sunshine_hours_total": {
        "MLP": {"hidden_layer_sizes": (48, 24), "alpha": 0.01},
        "XGBoost": {"max_depth": 2, "learning_rate": 0.03, "n_estimators": 250,
                     "subsample": 0.8, "colsample_bytree": 0.8},
        "LSTM": {"units": 16, "dropout": 0.1, "learning_rate": 0.001},
    },
    "temperature_c_mean": {
        "MLP": {"hidden_layer_sizes": (48, 24), "alpha": 0.01},
        "XGBoost": {"max_depth": 3, "learning_rate": 0.05, "n_estimators": 200,
                     "subsample": 0.9, "colsample_bytree": 0.9},
        "LSTM": {"units": 16, "dropout": 0.1, "learning_rate": 0.001},
    },
    "precipitation_mm_total": {
        "MLP": {"hidden_layer_sizes": (24,), "alpha": 0.001},
        "XGBoost": {"max_depth": 3, "learning_rate": 0.05, "n_estimators": 200,
                     "subsample": 0.9, "colsample_bytree": 0.9},
        "LSTM": {"units": 32, "dropout": 0.2, "learning_rate": 0.001},
    },
    "humidity_pct_mean": {
        "MLP": {"hidden_layer_sizes": (48, 24), "alpha": 0.01},
        "XGBoost": {"max_depth": 3, "learning_rate": 0.05, "n_estimators": 200,
                     "subsample": 0.9, "colsample_bytree": 0.9},
        "LSTM": {"units": 32, "dropout": 0.2, "learning_rate": 0.001},
    },
}


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.keras.utils.set_random_seed(seed)
        tf.config.experimental.enable_op_determinism()
    except Exception:
        pass


def load_data(path: Path) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name="Verified Monthly Data")
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.set_index("Date").sort_index()
    return df


def complete_training_history(series: pd.Series, origin: pd.Timestamp) -> pd.Series:
    train = series.loc[series.index < origin].copy()
    month_medians = train.groupby(train.index.month).median()
    global_median = float(train.median())
    for stamp in train.index[train.isna()]:
        train.loc[stamp] = month_medians.get(stamp.month, global_median)
    return train.astype(float)


def transform_target(values: np.ndarray, variable: str) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    return values


def inverse_target(values: np.ndarray, variable: str) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    return values


def calendar_features(stamp: pd.Timestamp) -> tuple[float, float]:
    angle = 2 * np.pi * (stamp.month - 1) / 12
    return float(np.sin(angle)), float(np.cos(angle))


def supervised(history: pd.Series, variable: str, window: int):
    z = transform_target(history.to_numpy(), variable)
    x, y = [], []
    for i in range(window, len(z)):
        s, c = calendar_features(history.index[i])
        x.append(np.r_[z[i-window:i], s, c])
        y.append(z[i])
    return np.asarray(x), np.asarray(y)


def recursive_learning_forecast(history: pd.Series, origin: pd.Timestamp, variable: str,
                                model_name: str, window: int = 24, seed: int = SEED) -> np.ndarray:
    set_seed(seed)
    x, y = supervised(history, variable, window)
    x_scaler, y_scaler = RobustScaler(), RobustScaler()
    xs = x_scaler.fit_transform(x)
    ys = y_scaler.fit_transform(y.reshape(-1, 1)).ravel()
    params = LEARNING_PARAMS[variable][model_name]

    if model_name == "MLP":
        model = MLPRegressor(
            hidden_layer_sizes=params["hidden_layer_sizes"], activation="relu",
            solver="adam", alpha=params["alpha"], batch_size=32,
            learning_rate_init=0.001, max_iter=500, early_stopping=True,
            validation_fraction=0.15, n_iter_no_change=25, tol=1e-4,
            shuffle=False, random_state=seed,
        )
        model.fit(xs, ys)
        predict = lambda row: float(model.predict(row)[0])
    elif model_name == "XGBoost":
        model = XGBRegressor(
            objective="reg:squarederror", random_state=seed, n_jobs=1,
            reg_lambda=1.0, reg_alpha=0.0, min_child_weight=1,
            **params,
        )
        model.fit(xs, ys, verbose=False)
        predict = lambda row: float(model.predict(row)[0])
    else:
        import tensorflow as tf
        tf.keras.backend.clear_session()
        split = max(int(len(xs) * 0.85), 1)
        xtr, xval = xs[:split], xs[split:]
        ytr, yval = ys[:split], ys[split:]
        xtr = xtr[:, :window].reshape((-1, window, 1))
        xval = xval[:, :window].reshape((-1, window, 1))
        model = tf.keras.Sequential([
            tf.keras.layers.Input((window, 1)),
            tf.keras.layers.LSTM(params["units"], activation="tanh",
                                 recurrent_activation="sigmoid"),
            tf.keras.layers.Dropout(params["dropout"]),
            tf.keras.layers.Dense(1, activation="linear"),
        ])
        model.compile(optimizer=tf.keras.optimizers.Adam(params["learning_rate"]), loss="mse")
        callbacks = [tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=20, min_delta=1e-5,
            restore_best_weights=True, mode="min")]
        model.fit(xtr, ytr, validation_data=(xval, yval), epochs=250,
                  batch_size=32, shuffle=False, verbose=0, callbacks=callbacks)
        def predict(row):
            seq = row[0, :window].reshape((1, window, 1))
            return float(model.predict(seq, verbose=0).ravel()[0])

    z_history = transform_target(history.to_numpy(), variable).tolist()
    forecasts = []
    for h in range(HORIZON):
        stamp = origin + pd.DateOffset(months=h)
        s, c = calendar_features(stamp)
        row = np.r_[z_history[-window:], s, c].reshape(1, -1)
        row_s = x_scaler.transform(row)
        pred_s = predict(row_s)
        pred_z = float(y_scaler.inverse_transform([[pred_s]])[0, 0])
        forecasts.append(float(inverse_target([pred_z], variable)[0]))
        z_history.append(pred_z)
    return np.asarray(forecasts)


def statistical_forecasts(history: pd.Series, origin: pd.Timestamp, variable: str) -> dict[str, np.ndarray]:
    out = {}
    future = pd.date_range(origin, periods=HORIZON, freq="MS")
    out["Seasonal Naive"] = np.asarray([history.loc[d - pd.DateOffset(years=1)] for d in future])
    out["Climatology"] = np.asarray([history[history.index.month == d.month].mean() for d in future])

    sarima = SARIMAX(history, order=(1, 0, 1), seasonal_order=(1, 1, 1, 12),
                     enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=200)
    out["SARIMA"] = np.asarray(sarima.forecast(HORIZON))

    order, seasonal = AUTO_ORDERS[variable]
    auto = SARIMAX(history, order=order, seasonal_order=seasonal,
                   enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=200)
    out["Auto.ARIMA"] = np.asarray(auto.forecast(HORIZON))

    tbats = TBATS(seasonal_periods=[12], use_box_cox=False, use_trend=True,
                  use_damped_trend=False, use_arma_errors=False, n_jobs=1,
                  multiprocessing_start_method="spawn").fit(history.to_numpy())
    out["TBATS"] = np.asarray(tbats.forecast(HORIZON))
    if variable in {"sunshine_hours_total", "precipitation_mm_total", "humidity_pct_mean"}:
        for key in out:
            if key != "Climatology" or variable != "humidity_pct_mean":
                out[key] = np.maximum(out[key], 0)
    return out


def run_robustness(data: pd.DataFrame) -> pd.DataFrame:
    rows = []
    total = len(VARIABLES) * len(ROBUSTNESS_ORIGINS)
    done = 0
    for variable, column in VARIABLES.items():
        series = data[column]
        for origin in ROBUSTNESS_ORIGINS:
            started = time.time()
            history = complete_training_history(series, origin)
            forecasts = statistical_forecasts(history, origin, variable)
            for model in ("MLP", "XGBoost", "LSTM"):
                forecasts[model] = recursive_learning_forecast(history, origin, variable, model)
            targets = pd.date_range(origin, periods=HORIZON, freq="MS")
            for model, pred in forecasts.items():
                for lead, (stamp, value) in enumerate(zip(targets, pred), 1):
                    actual = series.get(stamp, np.nan)
                    rows.append({"variable": variable, "origin": origin, "origin_month": origin.month,
                                 "lead": lead, "target_date": stamp, "model": model,
                                 "actual": actual, "prediction": float(value)})
            done += 1
            print(f"[{done}/{total}] {variable} {origin.date()} {time.time()-started:.1f}s", flush=True)
    result = pd.DataFrame(rows)
    result["error"] = result["prediction"] - result["actual"]
    result["abs_error"] = result["error"].abs()
    result["sq_error"] = result["error"] ** 2
    return result


def aggregate_metrics(pred: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    rows = []
    for keys, g in pred.dropna(subset=["actual"]).groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple): keys = (keys,)
        row = dict(zip(group_cols, keys))
        row.update(n=len(g), RMSE=float(np.sqrt(g.sq_error.mean())),
                   MAE=float(g.abs_error.mean()), Bias=float(g.error.mean()))
        rows.append(row)
    return pd.DataFrame(rows)


def leave_one_origin_out(pred: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for variable, gv in pred.groupby("variable"):
        origins = sorted(gv.origin.unique())
        for omitted in origins:
            g = gv[gv.origin != omitted].dropna(subset=["actual"])
            metrics = aggregate_metrics(g, ["model"])
            metrics["variable"] = variable
            metrics["omitted_origin"] = omitted
            rows.append(metrics)
    out = pd.concat(rows, ignore_index=True)
    out["rank"] = out.groupby(["variable", "omitted_origin"])["RMSE"].rank(method="min")
    return out


def precipitation_contingency(pred: pd.DataFrame, data: pd.DataFrame) -> pd.DataFrame:
    series = data[VARIABLES["precipitation_mm_total"]]
    threshold = float(series.loc[series.index < ROBUSTNESS_ORIGINS.min()].quantile(.9))
    g = pred[pred.variable == "precipitation_mm_total"].dropna(subset=["actual"])
    rows = []
    for model, m in g.groupby("model"):
        event, called = m.actual > threshold, m.prediction > threshold
        hit = int((event & called).sum()); miss = int((event & ~called).sum())
        fa = int((~event & called).sum()); cn = int((~event & ~called).sum())
        rows.append({"model": model, "threshold_mm": threshold, "n": len(m),
                     "hits": hit, "misses": miss, "false_alarms": fa, "correct_negatives": cn,
                     "POD": hit/(hit+miss) if hit+miss else np.nan,
                     "FAR": fa/(hit+fa) if hit+fa else np.nan,
                     "CSI": hit/(hit+miss+fa) if hit+miss+fa else np.nan})
    return pd.DataFrame(rows)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    source = root / "library_inputs" / "Van_Station_Verified_Data_and_QC.xlsx"
    outdir = root / "analysis" / "outputs"
    outdir.mkdir(parents=True, exist_ok=True)
    data = load_data(source)
    predictions_path = outdir / "calendar_balanced_predictions.csv"
    if predictions_path.exists():
        predictions = pd.read_csv(predictions_path, parse_dates=["origin", "target_date"])
    else:
        predictions = run_robustness(data)
        predictions.to_csv(predictions_path, index=False)

    overall = aggregate_metrics(predictions, ["variable", "model"])
    per_origin = aggregate_metrics(predictions, ["variable", "model", "origin"])
    by_origin_month = aggregate_metrics(predictions, ["variable", "model", "origin_month"])
    by_lead = aggregate_metrics(predictions, ["variable", "model", "lead"])
    loo = leave_one_origin_out(predictions)
    contingency = precipitation_contingency(predictions, data)

    summary = (loo.groupby(["variable", "model"])
               .agg(loo_rmse_min=("RMSE", "min"), loo_rmse_max=("RMSE", "max"),
                    loo_mean_rank=("rank", "mean"), loo_wins=("rank", lambda x: int((x == 1).sum())))
               .reset_index())
    metadata = pd.DataFrame([
        ("seed", SEED), ("origins", f"{ROBUSTNESS_ORIGINS.min():%Y-%m} to {ROBUSTNESS_ORIGINS.max():%Y-%m}"),
        ("n_origins", len(ROBUSTNESS_ORIGINS)), ("horizon_months", HORIZON),
        ("learning_forecast", "recursive; predictions appended in transformed target space"),
        ("LSTM_loss", "mean squared error"), ("LSTM_batch_size", 32),
        ("LSTM_max_epochs", 250), ("LSTM_patience", 20),
        ("LSTM_monitor", "chronological final 15% of training sequences; val_loss"),
        ("MLP_solver", "Adam"), ("MLP_max_iter", 500), ("MLP_patience", 25),
        ("inference", "descriptive robustness; no winner-selected p-values"),
    ], columns=["element", "specification"])

    with pd.ExcelWriter(outdir / "JAWRA_Minor_Revision_Robustness.xlsx", engine="openpyxl") as writer:
        overall.to_excel(writer, "Overall metrics", index=False)
        per_origin.to_excel(writer, "Per-origin metrics", index=False)
        by_origin_month.to_excel(writer, "Origin-month metrics", index=False)
        by_lead.to_excel(writer, "Lead metrics descriptive", index=False)
        loo.to_excel(writer, "Leave-one-origin-out", index=False)
        summary.to_excel(writer, "LOO summary", index=False)
        contingency.to_excel(writer, "Precip contingency", index=False)
        predictions.to_excel(writer, "Predictions", index=False)
        metadata.to_excel(writer, "Methods", index=False)
    print(json.dumps({"rows": len(predictions), "output": str(outdir)}, indent=2))


if __name__ == "__main__":
    main()
