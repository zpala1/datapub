#!/usr/bin/env python3
"""Validation RMSE/MAE plus targeted precipitation seed/window sensitivity."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import rebuild_jawra_pipeline as core

VALIDATION_ORIGINS = pd.date_range("2013-01-01", "2017-01-01", freq="12MS")
CANDIDATES = {
    "MLP": [
        {"hidden_layer_sizes": (24,), "alpha": 0.001},
        {"hidden_layer_sizes": (48, 24), "alpha": 0.01},
    ],
    "XGBoost": [
        {"max_depth": 2, "learning_rate": 0.03, "n_estimators": 250, "subsample": 0.8, "colsample_bytree": 0.8},
        {"max_depth": 3, "learning_rate": 0.05, "n_estimators": 200, "subsample": 0.9, "colsample_bytree": 0.9},
    ],
    "LSTM": [
        {"units": 16, "dropout": 0.1, "learning_rate": 0.001},
        {"units": 32, "dropout": 0.2, "learning_rate": 0.001},
    ],
}

def evaluate(data, variable, column, model, params, window=24, seed=core.SEED,
             target_scale="current"):
    records=[]
    old=core.LEARNING_PARAMS[variable][model]
    old_transform=core.transform_target
    old_inverse=core.inverse_target
    core.LEARNING_PARAMS[variable][model]=params
    if variable == "precipitation_mm_total" and target_scale == "log1p":
        core.transform_target=lambda values, _variable: np.log1p(np.maximum(np.asarray(values, dtype=float), 0.0))
        core.inverse_target=lambda values, _variable: np.maximum(np.expm1(np.asarray(values, dtype=float)), 0.0)
    try:
        for origin in VALIDATION_ORIGINS:
            hist=core.complete_training_history(data[column],origin)
            pred=core.recursive_learning_forecast(hist,origin,variable,model,window=window,seed=seed)
            dates=pd.date_range(origin,periods=12,freq='MS')
            actual=data[column].reindex(dates).to_numpy(float)
            mask=np.isfinite(actual)
            records.extend((origin,d,a,p) for d,a,p,m in zip(dates,actual,pred,mask) if m)
    finally:
        core.LEARNING_PARAMS[variable][model]=old
        core.transform_target=old_transform
        core.inverse_target=old_inverse
    a=np.array([r[2] for r in records]); p=np.array([r[3] for r in records])
    return len(a),float(np.sqrt(np.mean((p-a)**2))),float(np.mean(np.abs(p-a)))

def main():
    root=Path(__file__).resolve().parents[1]
    data=core.load_data(root/'library_inputs'/'Van_Station_Verified_Data_and_QC.xlsx')
    rows=[]; total=len(core.VARIABLES)*3*2; i=0
    for variable,column in core.VARIABLES.items():
        for model,candidates in CANDIDATES.items():
            for idx,params in enumerate(candidates,1):
                scale="log1p" if variable == "precipitation_mm_total" else "current"
                n,rmse,mae=evaluate(data,variable,column,model,params,target_scale=scale)
                rows.append(dict(analysis='candidate',variable=variable,model=model,variant=f'candidate_{idx}',
                                 window=24,seed=core.SEED,params=json.dumps(params),n=n,RMSE=rmse,MAE=mae))
                i+=1; print(f'candidate {i}/{total} {variable} {model} {idx}',flush=True)
    variable='precipitation_mm_total'; column=core.VARIABLES[variable]
    for model in CANDIDATES:
        params=core.LEARNING_PARAMS[variable][model]
        for window in (12,24,36):
            n,rmse,mae=evaluate(data,variable,column,model,params,window=window,seed=core.SEED,
                                target_scale="log1p")
            rows.append(dict(analysis='window',variable=variable,model=model,variant=f'window_{window}',
                             window=window,seed=core.SEED,params=json.dumps(params),n=n,RMSE=rmse,MAE=mae))
        for seed in (20261106,20261107,20261108):
            n,rmse,mae=evaluate(data,variable,column,model,params,window=24,seed=seed,
                                target_scale="log1p")
            rows.append(dict(analysis='seed',variable=variable,model=model,variant=f'seed_{seed}',
                             window=24,seed=seed,params=json.dumps(params),n=n,RMSE=rmse,MAE=mae))
    out=pd.DataFrame(rows)
    out.to_csv(root/'analysis/outputs/tuning_sensitivity.csv',index=False)
    print(out.to_string(index=False),flush=True)

if __name__=='__main__': main()
