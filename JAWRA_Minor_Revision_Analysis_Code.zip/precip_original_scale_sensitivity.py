#!/usr/bin/env python3
"""Original-scale precipitation sensitivity for the three learning models."""
from pathlib import Path
import pandas as pd
import rebuild_jawra_pipeline as core
import tuning_sensitivity as tune

def identity(values, variable):
    import numpy as np
    return np.asarray(values, dtype=float)

def main():
    root=Path(__file__).resolve().parents[1]
    data=core.load_data(root/'library_inputs'/'Van_Station_Verified_Data_and_QC.xlsx')
    old_t,old_i=core.transform_target,core.inverse_target
    core.transform_target=identity; core.inverse_target=identity
    rows=[]
    try:
        variable='precipitation_mm_total'; column=core.VARIABLES[variable]
        for model in ('MLP','XGBoost','LSTM'):
            params=core.LEARNING_PARAMS[variable][model]
            n,rmse,mae=tune.evaluate(data,variable,column,model,params,window=24,seed=core.SEED)
            rows.append(dict(analysis='target_scale',variable=variable,model=model,
                             variant='original_scale',window=24,seed=core.SEED,
                             params=str(params),n=n,RMSE=rmse,MAE=mae))
            print(model,rmse,mae,flush=True)
    finally:
        core.transform_target=old_t; core.inverse_target=old_i
    pd.DataFrame(rows).to_csv(root/'analysis/outputs/precip_original_scale_sensitivity.csv',index=False)

if __name__=='__main__': main()
