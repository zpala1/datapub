#!/usr/bin/env python3
"""Replace precipitation learning-model predictions with original-scale fits."""
from pathlib import Path
import pandas as pd
import rebuild_jawra_pipeline as core

def main():
    root=Path(__file__).resolve().parents[1]
    out=root/'analysis'/'outputs'
    pred=pd.read_csv(out/'calendar_balanced_predictions.csv',parse_dates=['origin','target_date'])
    data=core.load_data(root/'library_inputs'/'Van_Station_Verified_Data_and_QC.xlsx')
    variable='precipitation_mm_total'; series=data[core.VARIABLES[variable]]
    replacement=[]
    for i,origin in enumerate(core.ROBUSTNESS_ORIGINS,1):
        hist=core.complete_training_history(series,origin)
        dates=pd.date_range(origin,periods=12,freq='MS')
        for model in ('MLP','XGBoost','LSTM'):
            vals=core.recursive_learning_forecast(hist,origin,variable,model)
            for lead,(date,value) in enumerate(zip(dates,vals),1):
                replacement.append(dict(variable=variable,origin=origin,origin_month=origin.month,
                                        lead=lead,target_date=date,model=model,actual=series.get(date),
                                        prediction=max(float(value),0)))
        print(i,origin.date(),flush=True)
    new=pd.DataFrame(replacement)
    new['error']=new.prediction-new.actual; new['abs_error']=new.error.abs(); new['sq_error']=new.error**2
    keep=~((pred.variable==variable)&(pred.model.isin(['MLP','XGBoost','LSTM'])))
    final=pd.concat([pred[keep],new],ignore_index=True).sort_values(['variable','origin','model','lead'])
    final.to_csv(out/'calendar_balanced_predictions.csv',index=False)
    # The main script will aggregate the existing prediction file without re-fitting.
    core.main()

if __name__=='__main__': main()
