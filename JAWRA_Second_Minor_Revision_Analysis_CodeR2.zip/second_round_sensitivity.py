#!/usr/bin/env python3
"""Second-round robustness analyses for JAWRA manuscript 7173851.

Produces:
1. Unique-target-month metrics from the archived calendar-balanced predictions.
2. Target-month multiplicity counts.
3. A complete audit of learning-model candidate selection by validation MAE.
4. Relative-humidity sensitivity to three training-history treatments.

No forecast is updated with observations inside its 12-month horizon.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "analysis"))
import rebuild_jawra_pipeline as core  # noqa: E402

OUT = ROOT / "analysis" / "outputs" / "second_round"
OUT.mkdir(parents=True, exist_ok=True)

JANUARY_ORIGINS = pd.date_range("2018-01-01", "2022-01-01", freq="12MS")
HUMIDITY_VARIABLE = "humidity_pct_mean"
HUMIDITY_COLUMN = core.VARIABLES[HUMIDITY_VARIABLE]
MODELS = ["Seasonal Naive", "Climatology", "Auto.ARIMA", "SARIMA", "TBATS", "MLP", "XGBoost", "LSTM"]


def metric_rows(frame: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    rows: list[dict] = []
    for keys, group in frame.dropna(subset=["actual"]).groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        err = group["prediction"].to_numpy(float) - group["actual"].to_numpy(float)
        row = dict(zip(group_cols, keys))
        row.update(
            n=int(len(err)),
            RMSE=float(np.sqrt(np.mean(err**2))),
            MAE=float(np.mean(np.abs(err))),
            Bias=float(np.mean(err)),
        )
        rows.append(row)
    out = pd.DataFrame(rows)
    rank_group = [col for col in group_cols if col != "model"]
    out["RMSE_rank"] = out.groupby(rank_group, dropna=False)["RMSE"].rank(method="min") if rank_group else out["RMSE"].rank(method="min")
    return out


def unique_target_analyses() -> None:
    path = ROOT / "analysis" / "outputs" / "calendar_balanced_predictions.csv"
    pred = pd.read_csv(path, parse_dates=["origin", "target_date"])

    multiplicity = (
        pred[pred["model"].eq("Auto.ARIMA")]
        .groupby(["variable", "target_date"], as_index=False)
        .agg(forecast_positions=("origin", "size"), observed=("actual", lambda x: bool(x.notna().any())))
    )
    multiplicity.to_csv(OUT / "target_month_multiplicity.csv", index=False)

    records = []
    for rule in ("latest_available", "earliest_available", "mean_across_origins"):
        if rule == "latest_available":
            unique = (
                pred.sort_values(["variable", "model", "target_date", "lead"])
                .groupby(["variable", "model", "target_date"], as_index=False)
                .first()
            )
        elif rule == "earliest_available":
            unique = (
                pred.sort_values(["variable", "model", "target_date", "lead"], ascending=[True, True, True, False])
                .groupby(["variable", "model", "target_date"], as_index=False)
                .first()
            )
        else:
            unique = (
                pred.groupby(["variable", "model", "target_date"], as_index=False)
                .agg(actual=("actual", "first"), prediction=("prediction", "mean"))
            )
        unique["selection_rule"] = rule
        records.append(unique[["selection_rule", "variable", "model", "target_date", "actual", "prediction"]])

    unique_predictions = pd.concat(records, ignore_index=True)
    unique_predictions.to_csv(OUT / "unique_target_predictions.csv", index=False)
    metrics = metric_rows(unique_predictions, ["selection_rule", "variable", "model"])

    # Skill is expressed relative to climatology on the same unique targets.
    clim_mse = (
        metrics[metrics["model"].eq("Climatology")]
        .set_index(["selection_rule", "variable"])["RMSE"]
        .pow(2)
        .to_dict()
    )
    metrics["MSE_skill_vs_climatology"] = [
        1.0 - (row.RMSE**2 / clim_mse[(row.selection_rule, row.variable)])
        for row in metrics.itertuples()
    ]
    metrics.to_csv(OUT / "unique_target_metrics.csv", index=False)

    # Event counts for the prespecified calendar-balanced threshold. The
    # threshold is 69.90 mm because it is estimated from data before July 2020;
    # the January-origin threshold (69.83 mm) uses data before January 2018.
    threshold = 69.90
    event_rows = []
    latest_precip = unique_predictions[
        unique_predictions["selection_rule"].eq("latest_available")
        & unique_predictions["variable"].eq("precipitation_mm_total")
    ].dropna(subset=["actual"])
    for model, group in latest_precip.groupby("model"):
        event = group["actual"] > threshold
        called = group["prediction"] > threshold
        hits = int((event & called).sum())
        misses = int((event & ~called).sum())
        false_alarms = int((~event & called).sum())
        correct_negatives = int((~event & ~called).sum())
        event_rows.append({
            "model": model,
            "threshold_mm": threshold,
            "n_unique_targets": int(len(group)),
            "observed_event_months": int(event.sum()),
            "hits": hits,
            "misses": misses,
            "false_alarms": false_alarms,
            "correct_negatives": correct_negatives,
            "POD": hits / (hits + misses) if hits + misses else np.nan,
            "FAR": false_alarms / (hits + false_alarms) if hits + false_alarms else np.nan,
            "CSI": hits / (hits + misses + false_alarms) if hits + misses + false_alarms else np.nan,
        })
    pd.DataFrame(event_rows).to_csv(OUT / "unique_target_event_contingency.csv", index=False)


def candidate_selection_audit() -> None:
    tuning = pd.read_csv(ROOT / "analysis" / "outputs" / "tuning_sensitivity.csv")
    candidates = tuning[tuning["analysis"].eq("candidate")].copy()
    candidates["selected_by_min_MAE"] = False
    idx = candidates.groupby(["variable", "model"])["MAE"].idxmin()
    candidates.loc[idx, "selected_by_min_MAE"] = True

    used = []
    for variable in core.VARIABLES:
        for model in ("MLP", "XGBoost", "LSTM"):
            used.append({
                "variable": variable,
                "model": model,
                "used_params": json.dumps(core.LEARNING_PARAMS[variable][model], sort_keys=True),
            })
    used = pd.DataFrame(used)
    candidates["params_normalized"] = candidates["params"].map(lambda x: json.dumps(json.loads(x), sort_keys=True))
    audit = candidates.merge(used, on=["variable", "model"], how="left")
    audit["used_in_forecast_code"] = audit["params_normalized"].eq(audit["used_params"])
    audit["selection_consistent"] = audit["selected_by_min_MAE"].eq(audit["used_in_forecast_code"])
    audit.to_csv(OUT / "candidate_selection_audit.csv", index=False)


def complete_humidity_history(series: pd.Series, origin: pd.Timestamp, method: str) -> pd.Series:
    train = series.loc[series.index < origin].copy().astype(float)
    if method == "month_median":
        month_medians = train.groupby(train.index.month).median()
        global_median = float(train.median())
        for stamp in train.index[train.isna()]:
            train.loc[stamp] = month_medians.get(stamp.month, global_median)
    elif method == "time_interpolation":
        train = train.interpolate(method="time", limit_direction="both")
    elif method == "post_gap_1969":
        train = train.loc[train.index >= pd.Timestamp("1969-01-01")].copy()
        month_medians = train.groupby(train.index.month).median()
        global_median = float(train.median())
        for stamp in train.index[train.isna()]:
            train.loc[stamp] = month_medians.get(stamp.month, global_median)
    else:
        raise ValueError(method)
    if train.isna().any():
        raise ValueError(f"Unresolved missing values for {method}")
    return train


def humidity_imputation_sensitivity() -> None:
    data = core.load_data(ROOT / "library_inputs" / "Van_Station_Verified_Data_and_QC.xlsx")
    series = data[HUMIDITY_COLUMN]
    rows = []
    methods = ("month_median", "time_interpolation", "post_gap_1969")
    total = len(methods) * len(JANUARY_ORIGINS)
    done = 0
    for method in methods:
        for origin in JANUARY_ORIGINS:
            started = time.time()
            history = complete_humidity_history(series, origin, method)
            forecasts = core.statistical_forecasts(history, origin, HUMIDITY_VARIABLE)
            for model in ("MLP", "XGBoost", "LSTM"):
                forecasts[model] = core.recursive_learning_forecast(history, origin, HUMIDITY_VARIABLE, model)
            targets = pd.date_range(origin, periods=12, freq="MS")
            for model in MODELS:
                values = forecasts[model]
                for lead, (stamp, prediction) in enumerate(zip(targets, values), 1):
                    rows.append({
                        "imputation_method": method,
                        "origin": origin,
                        "lead": lead,
                        "target_date": stamp,
                        "model": model,
                        "actual": series.get(stamp, np.nan),
                        "prediction": float(prediction),
                        "training_start": history.index.min(),
                        "training_n": len(history),
                    })
            done += 1
            print(f"humidity {done}/{total} {method} {origin.date()} {time.time()-started:.1f}s", flush=True)

    predictions = pd.DataFrame(rows)
    predictions.to_csv(OUT / "humidity_imputation_predictions.csv", index=False)
    metrics = metric_rows(predictions, ["imputation_method", "model"])
    metrics.to_csv(OUT / "humidity_imputation_metrics.csv", index=False)


def main() -> None:
    unique_target_analyses()
    candidate_selection_audit()
    humidity_imputation_sensitivity()
    print(f"Second-round outputs written to {OUT}")


if __name__ == "__main__":
    main()
