# JAWRA manuscript 7173851: second minor revision reproducibility package

This package rebuilds the forecasting workflow from the source-verified monthly data workbook.

## Second-round analyses

`second_round_sensitivity.py` addresses the additional review concerning repeated target months, learning-model selection, and the 1964–1968 relative-humidity gap. It produces:

- a unique-target-month evaluation retaining the latest available forecast for each observed target month;
- target-month multiplicity counts for the 24-origin calendar-balanced analysis;
- an audit matching all minimum-validation-MAE candidates to the configurations used in the forecast code;
- relative-humidity forecasts under calendar-month median completion, time interpolation, and a post-gap training window beginning in January 1969; and
- unique-target high-precipitation contingency counts.

The 288 calendar-balanced forecast positions correspond to 35 distinct target months. Precipitation has 33 distinct observed targets. The 14 high-precipitation positions correspond to two distinct event months.

## Main analysis

`rebuild_jawra_pipeline.py` evaluates eight approaches at 24 monthly forecast origins from July 2020 through June 2022. Each calendar month is represented exactly twice. Every origin produces a fixed 12-month forecast without updating from observations within the horizon.

`tuning_sensitivity.py` recomputes RMSE and MAE for both candidate configurations of every learning implementation over the 2013–2017 validation origins. It also evaluates 12-, 24-, and 36-month input windows and three random seeds for the precipitation learning models.

`precip_original_scale_sensitivity.py` compares the former `log1p`/`expm1` precipitation pipeline with training and forecasting directly in millimetres. The latter is retained in the main analysis because it reduced validation RMSE for all three learning implementations. `update_precip_original_scale.py` documents the one-time migration used to update the archived calendar-balanced prediction table.

The learning models use recursive prediction. After each step, the model's own prediction is appended to the lag window used for the next step. No observed future target or future covariate is used.

## Reproducibility settings

- Random seed: 20261106
- Input window: 24 months
- Calendar encoding: sine and cosine of target calendar month
- MLP: ReLU, Adam, batch size 32, maximum 500 iterations, patience 25
- XGBoost: squared-error objective and one CPU thread
- LSTM: tanh/sigmoid gates, linear output, MSE loss, Adam, batch size 32, maximum 250 epochs, patience 20
- LSTM monitoring set: chronological final 15% of training sequences at each origin
- Missing historical inputs: training-origin-specific calendar-month median
- Missing target observations: never imputed for scoring
- Precipitation learning target: original millimetre scale. A validation sensitivity showed lower RMSE than the former `log1p`/`expm1` pipeline for MLP, XGBoost, and LSTM.

## Outputs

The workbook contains overall, origin-specific, origin-month, and lead-specific metrics; leave-one-origin-out results; precipitation event contingency counts; individual predictions; and method settings. Lead-specific results are descriptive because the 12-month forecasts overlap.

The second-round workbook additionally contains `Unique targets`, `Unique events`, `Multiplicity`, `Humidity sensitivity`, and `Selection audit` worksheets. Leave-one-origin-out results are retained only as a descriptive perturbation check and are not treated as independent resampling or evidence of statistical significance.

The robustness interval is not described as an independent holdout. It is a retrospective calendar-balanced sensitivity analysis because dates in this period appeared in earlier submitted evaluations.

## Run

```bash
python -m pip install -r requirements.txt
python rebuild_jawra_pipeline.py
python tuning_sensitivity.py
python precip_original_scale_sensitivity.py
python second_round_sensitivity.py
```

The script expects `Van_Station_Verified_Data_and_QC.xlsx` in `../library_inputs/` relative to this directory.
